package com.moontv.app

import android.content.Context
import android.util.Log
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings

/**
 * Singleton manager for Mozilla GeckoRuntime.
 * Configures the browser engine settings: hardware acceleration, content blocking,
 * and WebExtension execution pipeline.
 */
object GeckoManager {
    private const val TAG = "GeckoManager"

    @Volatile
    private var runtimeInstance: GeckoRuntime? = null

    /**
     * Initializes or returns the shared GeckoRuntime singleton.
     */
    fun getRuntime(context: Context): GeckoRuntime {
        return runtimeInstance ?: synchronized(this) {
            runtimeInstance ?: createRuntime(context.applicationContext).also {
                runtimeInstance = it
            }
        }
    }

    /**
     * Explicitly warms up the GeckoRuntime during application startup.
     */
    fun init(context: Context) {
        getRuntime(context)
    }

    private fun createRuntime(context: Context): GeckoRuntime {
        Log.i(TAG, "Creating configured Mozilla GeckoRuntime instance...")

        val settings = GeckoRuntimeSettings.Builder()
            // Enable hardware acceleration and modern web platform APIs
            .javaScriptEnabled(true)
            .webManifest(true)
            // Enable GeckoView's built-in Content Blocking as an extra layer behind uBlock Origin
            .contentBlocking(
                ContentBlocking.Settings.Builder()
                    .antiTracking(ContentBlocking.AntiTracking.DEFAULT)
                    .safeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)
                    .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY)
                    .build()
            )
            // Allow about:config inspection in debug builds if needed
            .aboutConfigEnabled(BuildConfig.DEBUG)
            .build()

        val runtime = GeckoRuntime.create(context, settings)

        // Install or ensure the bundled uBlock Origin extension is active
        WebExtensionManager.initialize(runtime, context)

        return runtime
    }
}
