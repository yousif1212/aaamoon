package com.moontv.app

import android.content.Context
import android.util.Log
import java.io.*
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * High-performance, zero-dependency embedded HTTP server for Moon TV.
 * Binds strictly to 127.0.0.1 loopback interface.
 * Serves the bundled Moon TV web app from Android APK assets (assets/www/*).
 *
 * Serving on http://127.0.0.1:8080 ensures standard HTTP origin context for
 * WebExtension content scripts, localStorage, cookies, and CORS.
 */
object MoonTvWebServer {
    private const val TAG = "MoonTvWebServer"
    private const val ASSETS_WWW_PREFIX = "www"

    @Volatile
    private var isRunning = false
    private var serverSocket: ServerSocket? = null
    private val threadPool = Executors.newCachedThreadPool()

    fun start(context: Context, port: Int = 8080) {
        if (isRunning) return

        threadPool.execute {
            try {
                // Bind exclusively to localhost loopback for security
                serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
                isRunning = true
                Log.i(TAG, "Moon TV internal server started on http://127.0.0.1:$port")

                while (isRunning && !serverSocket!!.isClosed) {
                    try {
                        val client = serverSocket!!.accept()
                        threadPool.execute { handleClient(context, client) }
                    } catch (e: Exception) {
                        if (isRunning) {
                            Log.w(TAG, "Error accepting connection: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to bind internal server socket on port $port", e)
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            // Ignore socket close exception
        }
    }

    private fun handleClient(context: Context, client: Socket) {
        try {
            client.use { socket ->
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val output = BufferedOutputStream(socket.getOutputStream())

                val requestLine = reader.readLine() ?: return
                val tokens = requestLine.split(" ")
                if (tokens.size < 2 || tokens[0] != "GET") {
                    send405(output)
                    return
                }

                var path = tokens[1].substringBefore("?")
                if (path == "/" || path.isEmpty()) {
                    path = "/index.html"
                }

                // Sanitize path against directory traversal
                val relativePath = path.trimStart('/').replace("..", "")
                val assetPath = "$ASSETS_WWW_PREFIX/$relativePath"

                try {
                    context.assets.open(assetPath).use { assetStream ->
                        val bytes = assetStream.readBytes()
                        val mimeType = getMimeType(relativePath)

                        val header = StringBuilder().apply {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: $mimeType\r\n")
                            append("Content-Length: ${bytes.size}\r\n")
                            append("Connection: close\r\n")
                            append("Access-Control-Allow-Origin: *\r\n")
                            append("Cache-Control: no-cache\r\n")
                            append("\r\n")
                        }.toString()

                        output.write(header.toByteArray(Charsets.UTF_8))
                        output.write(bytes)
                        output.flush()
                    }
                } catch (fnf: FileNotFoundException) {
                    send404(output, path)
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Connection handling note: ${e.message}")
        }
    }

    private fun getMimeType(path: String): String {
        return when {
            path.endsWith(".html") || path.endsWith(".htm") -> "text/html; charset=UTF-8"
            path.endsWith(".js") -> "application/javascript; charset=UTF-8"
            path.endsWith(".css") -> "text/css; charset=UTF-8"
            path.endsWith(".json") -> "application/json; charset=UTF-8"
            path.endsWith(".png") -> "image/png"
            path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
            path.endsWith(".gif") -> "image/gif"
            path.endsWith(".svg") -> "image/svg+xml"
            path.endsWith(".ico") -> "image/x-icon"
            path.endsWith(".woff2") -> "font/woff2"
            path.endsWith(".woff") -> "font/woff"
            path.endsWith(".ttf") -> "font/ttf"
            else -> "application/octet-stream"
        }
    }

    private fun send404(output: OutputStream, path: String) {
        val body = "404 Not Found: $path".toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: ${body.size}\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(body)
        output.flush()
    }

    private fun send405(output: OutputStream) {
        val body = "405 Method Not Allowed".toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 405 Method Not Allowed\r\nContent-Type: text/plain\r\nContent-Length: ${body.size}\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(body)
        output.flush()
    }
}
