#!/bin/bash
# Script to generate a release signing key for Moon TV APK
set -e

KEYSTORE_PATH="moon-tv.keystore"
KEY_ALIAS="moontv"
KEY_PASS="moontv123"
STORE_PASS="moontv123"
VALIDITY_DAYS=10000

echo "Generating release keystore at $KEYSTORE_PATH..."
keytool -genkeypair \
    -v \
    -keystore "$KEYSTORE_PATH" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity $VALIDITY_DAYS \
    -storepass "$STORE_PASS" \
    -keypass "$KEY_PASS" \
    -dname "CN=Moon TV, OU=Streaming, O=Moon TV Entertainment, L=Global, ST=Earth, C=US"

echo "Keystore created successfully!"
echo "Keystore file: $KEYSTORE_PATH"
echo "Alias: $KEY_ALIAS"
echo "Password: $STORE_PASS"
