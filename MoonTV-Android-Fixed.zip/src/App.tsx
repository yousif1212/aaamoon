/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Play,
  RotateCw,
  Download,
  FolderTree,
  FileCode,
  Terminal,
  Cpu,
  Layers,
  Settings,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Search,
  Tv,
  Film,
  Flame,
  Star,
  X,
  Copy,
  Check,
  Power,
  ChevronRight,
  Sparkles,
  Smartphone,
  Eye,
  Info
} from 'lucide-react';

interface MovieItem {
  id: number;
  title?: string;
  name?: string;
  media_type?: string;
  poster_path?: string;
  backdrop_path?: string;
  overview?: string;
  vote_average?: number;
  release_date?: string;
  first_air_date?: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'app' | 'project' | 'build' | 'docs'>('app');

  // Moon TV State
  const [mediaList, setMediaList] = useState<MovieItem[]>([]);
  const [filteredList, setFilteredList] = useState<MovieItem[]>([]);
  const [mediaTypeFilter, setMediaTypeFilter] = useState<'all' | 'tv' | 'movie'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [heroMedia, setHeroMedia] = useState<MovieItem | null>(null);

  // Player Modal State
  const [selectedMedia, setSelectedMedia] = useState<MovieItem | null>(null);
  const [currentServer, setCurrentServer] = useState<'vidsrc' | '2embed'>('vidsrc');
  const [season, setSeason] = useState(1);
  const [episode, setEpisode] = useState(1);
  const [totalEpisodes, setTotalEpisodes] = useState(12);

  // GeckoView & uBlock Origin Simulation State
  const [uBlockActive, setUBlockActive] = useState(true);
  const [showUBlockModal, setShowUBlockModal] = useState(false);
  const [blockedStats, setBlockedStats] = useState({
    adsBlocked: 19,
    trackersBlocked: 7,
    popupsSuppressed: 4,
    domainsBlocked: ['bancadeltempoidea.org', 'doubleclick.net', 'adnxs.com', 'popads.net', 'trackers.vidsrc.to']
  });

  // Code Explorer State
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copiedCode, setCopiedCode] = useState(false);

  // TMDB Setup
  const API_KEY = '3fd2be6f0c70a2a598f084ddfb75487c';
  const BASE_IMG = 'https://image.tmdb.org/t/p/w500';
  const BACKDROP_IMG = 'https://image.tmdb.org/t/p/original';

  useEffect(() => {
    fetchTrending('all');
  }, []);

  const fetchTrending = async (type: string) => {
    setLoading(true);
    try {
      const endpoint = type === 'all' ? '/trending/all/day' : `/trending/${type}/day`;
      const res = await fetch(`https://api.themoviedb.org/3${endpoint}?api_key=${API_KEY}&language=en-US`);
      const data = await res.json();
      const results: MovieItem[] = (data.results || []).filter((x: MovieItem) => x.media_type !== 'person');
      setMediaList(results);
      setFilteredList(results);
      if (results.length > 0) {
        setHeroMedia(results[0]);
      }
    } catch {
      // Fallback fallback sample items if TMDB has network limits
      const fallback: MovieItem[] = [
        {
          id: 1022789,
          title: 'Inside Out 2',
          media_type: 'movie',
          overview: 'Teenager Riley’s mind headquarters is undergoing a sudden demolition to make room for unexpected emotions.',
          vote_average: 7.6,
          release_date: '2024-06-11'
        },
        {
          id: 94605,
          name: 'Arcane',
          media_type: 'tv',
          overview: 'Amid the stark discord of twin cities Piltover and Zaun, two sisters fight on rival sides of a war.',
          vote_average: 8.7,
          first_air_date: '2021-11-06'
        },
        {
          id: 533535,
          title: 'Deadpool & Wolverine',
          media_type: 'movie',
          overview: 'A listless Wade Wilson toils away in civilian life with his days as the morally flexible mercenary Deadpool behind him.',
          vote_average: 7.7,
          release_date: '2024-07-24'
        }
      ];
      setMediaList(fallback);
      setFilteredList(fallback);
      setHeroMedia(fallback[0]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setFilteredList(mediaList);
      return;
    }
    try {
      const res = await fetch(`https://api.themoviedb.org/3/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(query)}`);
      const data = await res.json();
      const results: MovieItem[] = (data.results || []).filter(
        (x: MovieItem) => x.media_type === 'movie' || x.media_type === 'tv'
      );
      setFilteredList(results);
    } catch {
      setFilteredList(
        mediaList.filter(m => (m.title || m.name || '').toLowerCase().includes(query.toLowerCase()))
      );
    }
  };

  const handleFilterChange = (type: 'all' | 'tv' | 'movie') => {
    setMediaTypeFilter(type);
    if (type === 'all') {
      setFilteredList(mediaList);
    } else {
      setFilteredList(mediaList.filter(item => (item.media_type || (item.title ? 'movie' : 'tv')) === type));
    }
  };

  const openPlayer = (item: MovieItem) => {
    setSelectedMedia(item);
    setSeason(1);
    setEpisode(1);
    // Simulate uBlock Origin blocking streaming ad popups
    if (uBlockActive) {
      setBlockedStats(prev => ({
        ...prev,
        popupsSuppressed: prev.popupsSuppressed + 1,
        adsBlocked: prev.adsBlocked + 2
      }));
    }
  };

  const getPlayerUrl = () => {
    if (!selectedMedia) return '';
    const isTv = selectedMedia.media_type === 'tv' || (!selectedMedia.title && selectedMedia.name);
    if (!isTv) {
      return currentServer === 'vidsrc'
        ? `https://vidsrc.to/embed/movie/${selectedMedia.id}`
        : `https://www.2embed.cc/embed/${selectedMedia.id}`;
    } else {
      return currentServer === 'vidsrc'
        ? `https://vidsrc.to/embed/tv/${selectedMedia.id}/${season}/${episode}`
        : `https://www.2embed.cc/embedtv/${selectedMedia.id}&s=${season}&e=${episode}`;
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const codeFiles = [
    {
      title: 'MainActivity.kt',
      path: 'app/src/main/java/com/moontv/app/MainActivity.kt',
      tag: 'Kotlin / GeckoView UI',
      desc: 'Hosts GeckoView, connects to GeckoRuntime, auto-approves uBlock Origin permissions, prevents popup ad hijacking, and handles fullscreen video.',
      code: `package com.moontv.app

import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

class MainActivity : AppCompatActivity() {

    private lateinit var geckoView: GeckoView
    private lateinit var geckoSession: GeckoSession
    private lateinit var geckoRuntime: GeckoRuntime

    private lateinit var topBar: View
    private lateinit var loadingProgressBar: ProgressBar
    private lateinit var ublockStatusText: TextView
    private lateinit var shieldIcon: ImageView
    private lateinit var btnRefresh: ImageButton

    private var canGoBack: Boolean = false
    private var isFullScreen: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupGeckoEngine()
        setupBackNavigation()
        setupExtensionStatusListener()
    }

    private fun initViews() {
        geckoView = findViewById(R.id.geckoView)
        topBar = findViewById(R.id.topBar)
        loadingProgressBar = findViewById(R.id.loadingProgressBar)
        ublockStatusText = findViewById(R.id.ublockStatusText)
        shieldIcon = findViewById(R.id.shieldIcon)
        btnRefresh = findViewById(R.id.btnRefresh)

        btnRefresh.setOnClickListener {
            geckoSession.reload()
            Toast.makeText(this, "Reloading Moon TV...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupGeckoEngine() {
        Log.i("MoonTV", "Binding GeckoView and establishing GeckoSession...")

        // Retrieve pre-warmed GeckoRuntime singleton
        geckoRuntime = GeckoManager.getRuntime(this)

        geckoSession = GeckoSession().apply {
            // HTML5 Fullscreen video handler
            contentDelegate = object : GeckoSession.ContentDelegate {
                override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                    setFullScreenMode(fullScreen)
                }
            }

            // Suppress rogue popup ad tabs from video embed servers
            navigationDelegate = object : GeckoSession.NavigationDelegate {
                override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                    this@MainActivity.canGoBack = canGoBack
                }

                override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                    Log.i("MoonTV", "Suppressed popup ad attempt to open new session: \$uri")
                    return GeckoResult.fromValue(null) // Block popup
                }
            }

            progressDelegate = object : GeckoSession.ProgressDelegate {
                override fun onPageStart(session: GeckoSession, url: String) {
                    loadingProgressBar.visibility = View.VISIBLE
                }
                override fun onPageStop(session: GeckoSession, success: Boolean) {
                    loadingProgressBar.visibility = View.GONE
                }
            }

            // Auto-approve uBlock Origin extension permissions so user is never blocked
            promptDelegate = object : GeckoSession.PromptDelegate {
                override fun onExtensionInstallPrompt(
                    session: GeckoSession,
                    prompt: GeckoSession.PromptDelegate.ExtensionInstallPrompt
                ): GeckoResult<GeckoSession.PromptDelegate.PromptResponse> {
                    Log.i("MoonTV", "Auto-approving uBlock Origin extension permission prompt")
                    return GeckoResult.fromValue(prompt.confirm())
                }
            }

            open(geckoRuntime)
        }

        geckoView.setSession(geckoSession)

        // Load Moon TV Home Page (via internal server on 127.0.0.1:8080)
        val homeUrl = "http://127.0.0.1:\${MoonTvApplication.PORT}/index.html"
        Log.i("MoonTV", "Loading Moon TV Home Page: \$homeUrl")
        geckoSession.loadUri(homeUrl)
    }

    private fun setupExtensionStatusListener() {
        WebExtensionManager.addStatusListener { active, _ ->
            runOnUiThread {
                if (active) {
                    ublockStatusText.text = "uBlock ON"
                    ublockStatusText.setTextColor(ContextCompat.getColor(this, R.color.shield_green))
                    shieldIcon.setColorFilter(ContextCompat.getColor(this, R.color.shield_green))
                } else {
                    ublockStatusText.text = "uBlock INIT"
                    ublockStatusText.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                    shieldIcon.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary))
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isFullScreen) {
                    setFullScreenMode(false)
                } else if (canGoBack) {
                    geckoSession.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun setFullScreenMode(fullScreen: Boolean) {
        isFullScreen = fullScreen
        runOnUiThread {
            if (fullScreen) {
                topBar.visibility = View.GONE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            } else {
                topBar.visibility = View.VISIBLE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                window.insetsController?.show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            }
        }
    }
}`
    },
    {
      title: 'WebExtensionManager.kt',
      path: 'app/src/main/java/com/moontv/app/WebExtensionManager.kt',
      tag: 'XPI / WebExtension Engine',
      desc: 'Installs uBlock Origin XPI using ensureBuiltIn(), ensures automatic persistence across reboots, and enables ad/tracker filtering.',
      code: `package com.moontv.app

import android.content.Context
import android.util.Log
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.io.File
import java.io.FileOutputStream

object WebExtensionManager {
    private const val TAG = "WebExtensionManager"

    // Official ID declared in uBlock Origin manifest.json
    const val UBLOCK_EXTENSION_ID = "uBlock0@raymondhill.net"
    const val ASSET_EXTENSION_PATH = "extensions/ublock.xpi"

    @Volatile
    var uBlockExtension: WebExtension? = null
        private set

    @Volatile
    var isExtensionActive: Boolean = false
        private set

    private val statusListeners = mutableListOf<(Boolean, String) -> Unit>()

    fun initialize(runtime: GeckoRuntime, context: Context) {
        val controller = runtime.webExtensionController

        // Verify if extension is already installed in profile
        controller.list().accept(
            { extensions ->
                val existing = extensions?.find { it.id == UBLOCK_EXTENSION_ID }
                if (existing != null) {
                    Log.i(TAG, "uBlock Origin found in existing profile. Ensuring enabled...")
                    uBlockExtension = existing
                    enableExtension(controller, existing)
                } else {
                    Log.i(TAG, "uBlock Origin not found in profile. Installing bundled built-in XPI...")
                    installBundledExtension(controller, context)
                }
            },
            { throwable ->
                Log.w(TAG, "Error listing extensions, attempting direct install", throwable)
                installBundledExtension(controller, context)
            }
        )
    }

    private fun installBundledExtension(controller: WebExtensionController, context: Context) {
        val resourceUri = "resource://android/assets/\$ASSET_EXTENSION_PATH"
        Log.i(TAG, "Installing built-in WebExtension from URI: \$resourceUri")

        // ensureBuiltIn installs the XPI as a built-in extension on first launch
        // and persists automatically across app restarts
        controller.ensureBuiltIn(resourceUri, UBLOCK_EXTENSION_ID).accept(
            { extension ->
                if (extension != null) {
                    Log.i(TAG, "uBlock Origin successfully installed: \${extension.id}")
                    uBlockExtension = extension
                    enableExtension(controller, extension)
                } else {
                    installFromExtractedFile(controller, context)
                }
            },
            { throwable ->
                Log.e(TAG, "Failed via resource:// URI, falling back to local file", throwable)
                installFromExtractedFile(controller, context)
            }
        )
    }

    private fun installFromExtractedFile(controller: WebExtensionController, context: Context) {
        try {
            val extensionDir = File(context.filesDir, "extensions").apply { mkdirs() }
            val xpiFile = File(extensionDir, "ublock.xpi")

            if (!xpiFile.exists() || xpiFile.length() == 0L) {
                context.assets.open(ASSET_EXTENSION_PATH).use { input ->
                    FileOutputStream(xpiFile).use { output -> input.copyTo(output) }
                }
            }

            val fileUri = "file://\${xpiFile.absolutePath}"
            controller.installBuiltIn(fileUri).accept(
                { extension ->
                    uBlockExtension = extension
                    if (extension != null) enableExtension(controller, extension)
                },
                { throwable ->
                    notifyStatus(false, "Failed: \${throwable.message}")
                }
            )
        } catch (e: Exception) {
            notifyStatus(false, "Extraction error: \${e.message}")
        }
    }

    private fun enableExtension(controller: WebExtensionController, extension: WebExtension) {
        controller.enable(extension, WebExtensionController.EnableSource.USER).accept(
            {
                Log.i(TAG, "uBlock Origin is ENABLED and actively protecting web sessions.")
                isExtensionActive = true
                notifyStatus(true, "uBlock Origin Active & Protecting")
            },
            { throwable ->
                notifyStatus(false, "Failed to enable: \${throwable.message}")
            }
        )
    }

    fun addStatusListener(listener: (Boolean, String) -> Unit) {
        statusListeners.add(listener)
        listener(isExtensionActive, if (isExtensionActive) "Active" else "Initializing...")
    }

    private fun notifyStatus(active: Boolean, message: String) {
        isExtensionActive = active
        statusListeners.forEach { it(active, message) }
    }
}`
    },
    {
      title: 'MoonTvWebServer.kt',
      path: 'app/src/main/java/com/moontv/app/MoonTvWebServer.kt',
      tag: 'Embedded Local Host',
      desc: 'Zero-dependency localhost HTTP server (127.0.0.1:8080) giving Moon TV standard HTTP origin context for uBlock Origin content scripts and cosmetic filtering.',
      code: `package com.moontv.app

import android.content.Context
import android.util.Log
import java.io.*
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Serves the Moon TV HTML application from Android APK assets (assets/www/*)
 * over http://127.0.0.1:8080.
 *
 * This provides standard WebExtension origin matching (<all_urls>), allowing
 * uBlock Origin to inject cosmetic stylesheet rules, scriptlets, and filter network calls.
 */
object MoonTvWebServer {
    private const val TAG = "MoonTvWebServer"
    private const val ASSETS_WWW_PREFIX = "www"

    @Volatile
    private var isRunning = false
    private var serverSocket: ServerSocket? = null
    private val threadPool = Executors.newCachedThreadPool()

    fun start(context: Context, port: Int = 8080) {
        if (isRunning) return

        threadPool.execute {
            try {
                // Bind exclusively to localhost loopback for security
                serverSocket = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
                isRunning = true
                Log.i(TAG, "Moon TV internal server started on http://127.0.0.1:\$port")

                while (isRunning && !serverSocket!!.isClosed) {
                    val client = serverSocket!!.accept()
                    threadPool.execute { handleClient(context, client) }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server socket error on port \$port", e)
            }
        }
    }

    fun stop() {
        isRunning = false
        serverSocket?.close()
    }

    private fun handleClient(context: Context, client: Socket) {
        try {
            client.use { socket ->
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val output = BufferedOutputStream(socket.getOutputStream())

                val requestLine = reader.readLine() ?: return
                val tokens = requestLine.split(" ")
                if (tokens.size < 2 || tokens[0] != "GET") return

                var path = tokens[1].substringBefore("?")
                if (path == "/" || path.isEmpty()) path = "/index.html"

                val relativePath = path.trimStart('/').replace("..", "")
                val assetPath = "\$ASSETS_WWW_PREFIX/\$relativePath"

                try {
                    context.assets.open(assetPath).use { assetStream ->
                        val bytes = assetStream.readBytes()
                        val mimeType = getMimeType(relativePath)

                        val header = "HTTP/1.1 200 OK\\r\\n" +
                            "Content-Type: \$mimeType\\r\\n" +
                            "Content-Length: \${bytes.size}\\r\\n" +
                            "Access-Control-Allow-Origin: *\\r\\n\\r\\n"

                        output.write(header.toByteArray(Charsets.UTF_8))
                        output.write(bytes)
                        output.flush()
                    }
                } catch (_: FileNotFoundException) {
                    val notFound = "HTTP/1.1 404 Not Found\\r\\n\\r\\n404 File Not Found"
                    output.write(notFound.toByteArray(Charsets.UTF_8))
                    output.flush()
                }
            }
        } catch (_: Exception) {}
    }

    private fun getMimeType(path: String): String = when {
        path.endsWith(".html") -> "text/html; charset=UTF-8"
        path.endsWith(".js") -> "application/javascript; charset=UTF-8"
        path.endsWith(".css") -> "text/css; charset=UTF-8"
        path.endsWith(".png") -> "image/png"
        path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
        path.endsWith(".svg") -> "image/svg+xml"
        else -> "application/octet-stream"
    }
}`
    },
    {
      title: 'app/build.gradle.kts',
      path: 'app/build.gradle.kts',
      tag: 'Build & Dependencies',
      desc: 'Gradle app module script specifying GeckoView Omni AAR (multi-ABI) dependency and signing configuration.',
      code: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.moontv.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.moontv.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86"))
        }
    }

    signingConfigs {
        create("release") {
            val keystoreFile = file("../signing/moon-tv.keystore")
            if (keystoreFile.exists()) {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "moontv123"
                keyAlias = System.getenv("KEY_ALIAS") ?: "moontv"
                keyPassword = System.getenv("KEY_PASSWORD") ?: "moontv123"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Mozilla GeckoView Omni (Full native browser engine supporting all ABIs)
    implementation("org.mozilla.geckoview:geckoview-omni:130.0.20240829075237")
}`
    },
    {
      title: 'AndroidManifest.xml',
      path: 'app/src/main/AndroidManifest.xml',
      tag: 'Manifest & Permissions',
      desc: 'App manifest configuring Internet permissions, local cleartext network security, hardware acceleration, and Android TV support.',
      code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <!-- Optional Android TV support -->
    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
    <uses-feature android:name="android.software.leanback" android:required="false" />

    <application
        android:name=".MoonTvApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/Theme.MoonTV"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="true"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden|smallestScreenSize"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.MoonTV">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
            </intent-filter>
        </activity>

    </application>

</manifest>`
    },
    {
      title: 'generate_keystore.sh',
      path: 'signing/generate_keystore.sh',
      tag: 'Signing Tool',
      desc: 'Generates a 2048-bit RSA release signing certificate for Moon TV APK packaging.',
      code: `#!/bin/bash
set -e

KEYSTORE_PATH="moon-tv.keystore"
KEY_ALIAS="moontv"
KEY_PASS="moontv123"
STORE_PASS="moontv123"
VALIDITY_DAYS=10000

echo "Generating release keystore at \$KEYSTORE_PATH..."
keytool -genkeypair \\
    -v \\
    -keystore "\$KEYSTORE_PATH" \\
    -alias "\$KEY_ALIAS" \\
    -keyalg RSA \\
    -keysize 2048 \\
    -validity \$VALIDITY_DAYS \\
    -storepass "\$STORE_PASS" \\
    -keypass "\$KEY_PASS" \\
    -dname "CN=Moon TV, OU=Streaming, O=Moon TV Entertainment, L=Global, ST=Earth, C=US"

echo "Keystore created successfully!"`
    }
  ];

  return (
    <div className="min-h-screen bg-[#0d0d0f] text-gray-100 flex flex-col font-sans selection:bg-red-600 selection:text-white">
      {/* Top Navbar */}
      <header className="border-b border-zinc-800/80 bg-zinc-950/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center font-black text-xl text-white shadow-lg shadow-red-600/30">
              M
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-white">Moon <span className="text-red-500 font-extrabold">TV</span></span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-950/60 border border-red-700/60 text-red-400 font-mono font-semibold">
                  GeckoView Native
                </span>
              </div>
              <div className="text-xs text-zinc-400 hidden sm:block">
                Kotlin Android App + Bundled uBlock Origin XPI
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('app')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2 transition ${
                activeTab === 'app'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Live Moon TV</span>
            </button>
            <button
              onClick={() => setActiveTab('project')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2 transition ${
                activeTab === 'project'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <FolderTree className="w-4 h-4" />
              <span>Project Source</span>
            </button>
            <button
              onClick={() => setActiveTab('build')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2 transition ${
                activeTab === 'build'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <Terminal className="w-4 h-4" />
              <span>Build APK</span>
            </button>
            <button
              onClick={() => setActiveTab('docs')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2 transition ${
                activeTab === 'docs'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
              }`}
            >
              <Info className="w-4 h-4" />
              <span>Architecture</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col">
        {/* TAB 1: LIVE MOON TV + GECKOVIEW SIMULATOR */}
        {activeTab === 'app' && (
          <div className="flex flex-col gap-6">
            {/* GeckoView & uBlock Origin Runtime Banner */}
            <div className="bg-gradient-to-r from-zinc-900 via-zinc-900/95 to-zinc-900 border border-zinc-800 rounded-2xl p-4 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  uBlockActive ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-400' : 'bg-red-950/80 border border-red-500/40 text-red-400'
                }`}>
                  {uBlockActive ? <ShieldCheck className="w-7 h-7" /> : <ShieldAlert className="w-7 h-7" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-bold text-white text-base">
                      {uBlockActive ? 'uBlock Origin WebExtension is ACTIVE' : 'uBlock Origin Filtering DISABLED'}
                    </h2>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                      uBlockActive ? 'bg-emerald-900/40 text-emerald-400 border border-emerald-700/50' : 'bg-red-900/40 text-red-400 border border-red-700/50'
                    }`}>
                      {uBlockActive ? 'XPI Active' : 'Suspended'}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    GeckoRuntime: <span className="text-zinc-300 font-mono">130.0 Omni</span> | Extension ID: <span className="text-zinc-300 font-mono">uBlock0@raymondhill.net</span>
                  </p>
                </div>
              </div>

              {/* Stats & Actions */}
              <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                <div className="flex items-center gap-4 bg-zinc-950/80 border border-zinc-800 px-3.5 py-1.5 rounded-xl text-xs">
                  <div>
                    <span className="text-zinc-400">Ads Blocked: </span>
                    <span className="font-bold text-emerald-400 font-mono">{uBlockActive ? blockedStats.adsBlocked : 0}</span>
                  </div>
                  <div className="h-4 w-px bg-zinc-800" />
                  <div>
                    <span className="text-zinc-400">Popups: </span>
                    <span className="font-bold text-emerald-400 font-mono">{uBlockActive ? blockedStats.popupsSuppressed : 0}</span>
                  </div>
                </div>

                {/* uBlock Controls */}
                <button
                  onClick={() => setShowUBlockModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-semibold text-zinc-200 flex items-center gap-1.5 transition"
                >
                  <Shield className="w-3.5 h-3.5 text-red-500" />
                  <span>uBlock Panel</span>
                </button>

                <button
                  onClick={() => setUBlockActive(!uBlockActive)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                    uBlockActive
                      ? 'bg-zinc-800 hover:bg-red-950/50 text-zinc-300 border border-zinc-700'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                  }`}
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>{uBlockActive ? 'Turn Off Protection' : 'Enable uBlock'}</span>
                </button>
              </div>
            </div>

            {/* Simulated Banner Ad Warning when uBlock is OFF */}
            {!uBlockActive && (
              <div className="bg-red-950/40 border border-red-700/60 rounded-xl p-4 flex items-center justify-between gap-3 text-xs text-red-300 animate-pulse">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>
                    <strong>Unprotected Session:</strong> Without uBlock Origin, sponsored banners (like <code>bancadeltempoidea.org</code>) and redirect popups from streaming servers will execute.
                  </span>
                </div>
                <button
                  onClick={() => setUBlockActive(true)}
                  className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs shrink-0"
                >
                  Re-Enable
                </button>
              </div>
            )}

            {/* Sponsored Banner Ad Preview (Shown only when uBlock is OFF to demonstrate blocking) */}
            {!uBlockActive && (
              <div className="border border-yellow-700/60 bg-zinc-900 rounded-xl p-3 flex flex-col items-center justify-center text-center relative">
                <span className="text-[10px] text-zinc-500 font-semibold mb-1">Sponsored Ad Banner (Blocked by uBlock Origin in GeckoView)</span>
                <div className="w-full max-w-[400px] h-20 bg-zinc-950 rounded-lg flex items-center justify-center border border-zinc-800 text-zinc-400 text-xs">
                  <span>Ad network banner from <code>bancadeltempoidea.org</code></span>
                </div>
              </div>
            )}

            {/* Moon TV Navigation & Search */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
                <button
                  onClick={() => handleFilterChange('all')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                    mediaTypeFilter === 'all'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  All Releases
                </button>
                <button
                  onClick={() => handleFilterChange('tv')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    mediaTypeFilter === 'tv'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Tv className="w-3.5 h-3.5" /> TV Series
                </button>
                <button
                  onClick={() => handleFilterChange('movie')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    mediaTypeFilter === 'movie'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Film className="w-3.5 h-3.5" /> Movies
                </button>
              </div>

              {/* Search Bar */}
              <div className="relative min-w-[240px]">
                <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search movies & TV series..."
                  value={searchQuery}
                  onChange={e => handleSearch(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition"
                />
              </div>
            </div>

            {/* Hero Section */}
            {heroMedia && !searchQuery && (
              <div className="relative rounded-2xl overflow-hidden h-72 sm:h-80 bg-zinc-900 border border-zinc-800 shadow-2xl">
                {heroMedia.backdrop_path ? (
                  <img
                    src={`${BACKDROP_IMG}${heroMedia.backdrop_path}`}
                    alt={heroMedia.title || heroMedia.name}
                    className="absolute inset-0 w-full h-full object-cover object-top"
                  />
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-r from-red-950/60 to-zinc-950" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 flex flex-col max-w-2xl">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold w-fit mb-2">
                    <Flame className="w-3 h-3 text-yellow-300" /> Featured Trending
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-black text-white drop-shadow-md">
                    {heroMedia.title || heroMedia.name}
                  </h1>
                  <p className="text-zinc-300 text-xs sm:text-sm line-clamp-2 mt-2 leading-relaxed">
                    {heroMedia.overview || 'Experience this cinematic release streaming in Moon TV with GeckoView & uBlock Origin.'}
                  </p>
                  <div className="flex items-center gap-3 mt-4">
                    <button
                      onClick={() => openPlayer(heroMedia)}
                      className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-red-600/30 transition active:scale-95"
                    >
                      <Play className="w-4 h-4 fill-white" /> Watch Now
                    </button>
                    <span className="text-xs text-zinc-400 flex items-center gap-1 bg-black/60 backdrop-blur px-2.5 py-1 rounded-lg">
                      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                      {heroMedia.vote_average ? heroMedia.vote_average.toFixed(1) : '8.1'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Media Grid */}
            <div className="flex flex-col gap-3">
              <h3 className="font-bold text-sm text-zinc-200 flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-500" />
                {searchQuery ? `Search Results for "${searchQuery}"` : 'Top Trending Releases'}
              </h3>

              {loading ? (
                <div className="py-20 flex flex-col items-center justify-center text-zinc-400 text-sm gap-2">
                  <RotateCw className="w-6 h-6 animate-spin text-red-500" />
                  <span>Loading cinema data...</span>
                </div>
              ) : filteredList.length === 0 ? (
                <div className="py-16 text-center text-zinc-400 text-sm">
                  No matching titles found. Try another search.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {filteredList.map(item => {
                    const isTv = item.media_type === 'tv' || (!item.title && item.name);
                    const title = item.title || item.name || 'Untitled';
                    const date = (item.release_date || item.first_air_date || '').slice(0, 4);
                    const poster = item.poster_path ? `${BASE_IMG}${item.poster_path}` : 'https://placehold.co/500x750/181818/888?text=Moon+TV';

                    return (
                      <button
                        key={item.id}
                        onClick={() => openPlayer(item)}
                        className="group bg-zinc-900 border border-zinc-800/80 rounded-xl overflow-hidden text-left flex flex-col hover:border-red-600/60 hover:-translate-y-1 transition duration-200 shadow-md focus:outline-none"
                      >
                        <div className="relative aspect-[2/3] w-full bg-zinc-950 overflow-hidden">
                          <img
                            src={poster}
                            alt={title}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                          />
                          <span className="absolute top-2 left-2 bg-black/80 backdrop-blur-sm text-yellow-400 text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow">
                            <Star className="w-2.5 h-2.5 fill-yellow-400" />
                            {item.vote_average ? item.vote_average.toFixed(1) : '—'}
                          </span>
                          <span className="absolute top-2 right-2 bg-red-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow">
                            {isTv ? 'TV Series' : 'Movie'}
                          </span>
                        </div>
                        <div className="p-3 flex-1 flex flex-col justify-between w-full bg-zinc-900/60">
                          <div className="font-bold text-xs truncate text-white group-hover:text-red-400 transition">
                            {title}
                          </div>
                          <div className="flex justify-between items-center text-[10px] text-zinc-400 mt-2">
                            <span>{date || '2024'}</span>
                            <span className="text-red-500 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition">
                              Watch <Play className="w-2.5 h-2.5 fill-red-500" />
                            </span>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: NATIVE ANDROID PROJECT EXPLORER */}
        {activeTab === 'project' && (
          <div className="flex flex-col gap-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-zinc-900 border border-zinc-800 rounded-2xl p-5">
              <div>
                <h2 className="font-bold text-lg text-white flex items-center gap-2">
                  <FolderTree className="w-5 h-5 text-red-500" />
                  MoonTV-Android Project Explorer
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Complete, buildable Android project with Kotlin, Mozilla GeckoView Omni, and bundled uBlock Origin XPI.
                </p>
              </div>

              <a
                href="/downloads/MoonTV-Android-project.zip"
                download="MoonTV-Android-project.zip"
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-red-600/30 transition active:scale-95 shrink-0"
              >
                <Download className="w-4 h-4" /> Download Complete Project (.zip)
              </a>
            </div>

            {/* Code Viewer Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* File List */}
              <div className="lg:col-span-4 flex flex-col gap-2">
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider px-1">Source Code Files</span>
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden divide-y divide-zinc-800/60">
                  {codeFiles.map((file, idx) => (
                    <button
                      key={file.path}
                      onClick={() => setSelectedFileIndex(idx)}
                      className={`w-full p-3 text-left flex items-start gap-3 transition ${
                        selectedFileIndex === idx
                          ? 'bg-red-950/30 border-l-4 border-red-500 text-white'
                          : 'text-zinc-400 hover:text-white hover:bg-zinc-800/40'
                      }`}
                    >
                      <FileCode className={`w-4 h-4 mt-0.5 shrink-0 ${selectedFileIndex === idx ? 'text-red-500' : 'text-zinc-500'}`} />
                      <div className="truncate">
                        <div className="text-xs font-bold truncate text-white">{file.title}</div>
                        <div className="text-[10px] text-zinc-500 truncate">{file.path}</div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Assets Summary */}
                <div className="mt-4 p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs flex flex-col gap-2">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Bundled Assets in APK
                  </div>
                  <div className="text-[11px] text-zinc-400 font-mono flex flex-col gap-1">
                    <div>• <code>assets/extensions/ublock.xpi</code> (6.0 MB signed XPI)</div>
                    <div>• <code>assets/www/index.html</code> (Moon TV Web App)</div>
                  </div>
                </div>
              </div>

              {/* Code Display */}
              <div className="lg:col-span-8 flex flex-col bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-xl">
                <div className="p-3 bg-zinc-950 border-b border-zinc-800 flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-white font-mono">{codeFiles[selectedFileIndex].title}</span>
                    <span className="ml-2 text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono">
                      {codeFiles[selectedFileIndex].tag}
                    </span>
                  </div>

                  <button
                    onClick={() => copyToClipboard(codeFiles[selectedFileIndex].code)}
                    className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold flex items-center gap-1.5 transition"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="p-3 bg-zinc-900/80 border-b border-zinc-800/80 text-xs text-zinc-400">
                  {codeFiles[selectedFileIndex].desc}
                </div>

                <pre className="p-4 overflow-x-auto text-xs font-mono text-zinc-300 leading-relaxed max-h-[600px] select-text">
                  <code>{codeFiles[selectedFileIndex].code}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: APK BUILD & SIGNING STUDIO */}
        {activeTab === 'build' && (
          <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-xl">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Terminal className="w-6 h-6 text-red-500" />
                How to Build &amp; Sign Your Moon TV APK
              </h2>
              <p className="text-sm text-zinc-400 mt-2 leading-relaxed">
                Follow these instructions to compile a production-ready, release-signed APK using Android Studio or command-line Gradle.
              </p>

              <div className="mt-6 flex flex-col gap-6">
                {/* Method 1: Android Studio */}
                <div className="p-5 rounded-xl bg-zinc-950/80 border border-zinc-800">
                  <h3 className="font-bold text-base text-white flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center text-xs font-bold">1</span>
                    Build in Android Studio (Recommended)
                  </h3>
                  <ol className="mt-3 text-xs text-zinc-300 space-y-2 list-decimal list-inside leading-relaxed">
                    <li>Download and unzip <code className="text-red-400 font-mono">MoonTV-Android-project.zip</code>.</li>
                    <li>Launch <strong>Android Studio</strong> and select <strong>Open</strong>, then choose the unzipped <code className="font-mono">MoonTV-Android</code> directory.</li>
                    <li>Android Studio will sync Gradle automatically. The Mozilla Maven repository (<code className="font-mono text-zinc-400">https://maven.mozilla.org/maven2/</code>) is pre-configured.</li>
                    <li>From the top menu, click <strong>Build &gt; Generate Signed Bundle / APK</strong>.</li>
                    <li>Choose <strong>APK</strong>, select the included <code className="font-mono">signing/moon-tv.keystore</code> (Password: <code className="font-mono text-emerald-400">moontv123</code>, Alias: <code className="font-mono text-emerald-400">moontv</code>).</li>
                    <li>Select <strong>Release</strong> build type and check both <strong>V1 (Jar Signature)</strong> and <strong>V2 (Full APK Signature)</strong>.</li>
                    <li>Click <strong>Finish</strong>. Your signed APK will be output in <code className="font-mono text-zinc-400">app/release/app-release.apk</code>!</li>
                  </ol>
                </div>

                {/* Method 2: Command Line */}
                <div className="p-5 rounded-xl bg-zinc-950/80 border border-zinc-800">
                  <h3 className="font-bold text-base text-white flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center text-xs font-bold">2</span>
                    Build via Command Line / Terminal
                  </h3>
                  <div className="mt-3 flex flex-col gap-2">
                    <span className="text-xs text-zinc-400">Run the following commands in the project directory:</span>
                    <pre className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-emerald-400 overflow-x-auto">
{`# 1. Generate release keystore if not already created
cd signing
bash generate_keystore.sh
cd ..

# 2. Build release APK with Gradle
./gradlew assembleRelease

# 3. Sign the APK
cd signing
bash sign_apk.sh`}
                    </pre>
                  </div>
                </div>

                {/* Keystore Details Card */}
                <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-xs flex flex-col gap-3">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Pre-Configured Release Keystore Credentials
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-[11px]">
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Keystore File:</span>
                      <span className="text-white">signing/moon-tv.keystore</span>
                    </div>
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Key Alias:</span>
                      <span className="text-emerald-400">moontv</span>
                    </div>
                    <div className="bg-zinc-950 p-2.5 rounded-lg border border-zinc-800">
                      <span className="text-zinc-500 block text-[10px]">Password:</span>
                      <span className="text-emerald-400">moontv123</span>
                    </div>
                  </div>
                </div>

                {/* Direct Download Button */}
                <div className="flex justify-center pt-2">
                  <a
                    href="/downloads/MoonTV-Android-project.zip"
                    download="MoonTV-Android-project.zip"
                    className="px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm flex items-center gap-2 shadow-xl shadow-red-600/30 transition active:scale-95"
                  >
                    <Download className="w-5 h-5" /> Download MoonTV-Android-project.zip
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: TECHNICAL ARCHITECTURE & DEEP DIVE */}
        {activeTab === 'docs' && (
          <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full text-zinc-300 text-sm leading-relaxed">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Cpu className="w-6 h-6 text-red-500" />
                  GeckoView vs Android WebView: Why WebView Fails for Adblocking
                </h2>
                <p className="mt-2 text-zinc-400 text-xs">
                  An engineering breakdown of Mozilla GeckoView, WebExtension support, and uBlock Origin execution in native Android.
                </p>
              </div>

              {/* Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-red-950/20 border border-red-800/40 flex flex-col gap-2">
                  <div className="font-bold text-red-400 flex items-center gap-2 text-xs uppercase tracking-wider">
                    <X className="w-4 h-4 text-red-500" /> Android WebView Limitations
                  </div>
                  <ul className="text-xs text-zinc-300 space-y-1.5 list-disc list-inside">
                    <li><strong>No WebExtension Support:</strong> Cannot load Chrome (.crx) or Firefox (.xpi) extensions.</li>
                    <li><strong>No Cosmetic Filter Injection:</strong> Cannot parse or apply uBlock Origin’s CSS element-hiding syntax.</li>
                    <li><strong>No Scriptlet Defusing:</strong> Cannot defuse anti-adblock or inline redirect scripts inside iframes.</li>
                    <li><strong>Limited Interception:</strong> <code>shouldInterceptRequest</code> cannot modify HTTP response headers or block WebSocket connections effectively.</li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 flex flex-col gap-2">
                  <div className="font-bold text-emerald-400 flex items-center gap-2 text-xs uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Mozilla GeckoView Advantages
                  </div>
                  <ul className="text-xs text-zinc-300 space-y-1.5 list-disc list-inside">
                    <li><strong>Full WebExtension Engine:</strong> Powered by Firefox Quantum, supporting WebExtension API v2/v3.</li>
                    <li><strong>Real uBlock Origin XPI:</strong> Runs the exact same signed extension as desktop and mobile Firefox.</li>
                    <li><strong>webRequestBlocking:</strong> Zero-latency request cancellation before network packets are sent.</li>
                    <li><strong>Embedded WebServer Context:</strong> Standard <code>127.0.0.1:8080</code> origin permits full content-script DOM injection and CSS element removal.</li>
                  </ul>
                </div>
              </div>

              {/* Extension Installation & Permission Protocol */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col gap-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <Layers className="w-4 h-4 text-red-500" />
                  uBlock Origin Installation &amp; Persistence Pipeline
                </h3>
                <div className="text-xs space-y-2 text-zinc-400">
                  <p>
                    <strong>1. Bundled Built-in Packaging:</strong> The signed <code className="text-zinc-200">ublock.xpi</code> (Extension ID: <code className="text-emerald-400">uBlock0@raymondhill.net</code>) is bundled inside the APK at <code className="text-zinc-200">assets/extensions/ublock.xpi</code>.
                  </p>
                  <p>
                    <strong>2. First Launch Execution:</strong> In <code className="text-zinc-200">WebExtensionManager.kt</code>, GeckoView’s <code className="text-emerald-400">ensureBuiltIn("resource://android/assets/extensions/ublock.xpi", id)</code> is called. This installs the extension into the persistent Gecko profile.
                  </p>
                  <p>
                    <strong>3. Persistence Across Restarts:</strong> GeckoView retains installed extensions in its internal profile directory. On subsequent launches, <code className="text-zinc-200">ensureBuiltIn</code> verifies the extension is enabled without re-copying or re-prompting.
                  </p>
                  <p>
                    <strong>4. Seamless Auto-Approval:</strong> Broad permissions (<code className="text-zinc-200">&lt;all_urls&gt;</code>, <code className="text-zinc-200">webRequestBlocking</code>) are auto-approved through our implementation of <code className="text-emerald-400">GeckoSession.PromptDelegate.onExtensionInstallPrompt</code>, providing a 100% frictionless native app launch.
                  </p>
                </div>
              </div>

              {/* Streaming Embed Defense */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col gap-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Streaming Server Pop-Up Neutralization
                </h3>
                <p className="text-xs text-zinc-400">
                  Video embeds from servers like <strong>VidSrc</strong> and <strong>2Embed</strong> frequently attempt to spawn fullscreen redirect popups or open new tabs via <code>window.open</code>. In Moon TV:
                </p>
                <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-300">
                  {`navigationDelegate = object : GeckoSession.NavigationDelegate {
    override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
        Log.i("MoonTV", "Suppressed popup ad: $uri")
        return GeckoResult.fromValue(null) // Prevents popup window from opening
    }
}`}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* PLAYER MODAL (Exact Moon TV streaming UI) */}
      {selectedMedia && (
        <div className="fixed inset-0 z-50 bg-black/95 p-3 sm:p-6 flex items-center justify-center backdrop-blur-md">
          <div className="w-full max-w-4xl bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl flex flex-col">
            {/* Modal Header */}
            <div className="p-4 bg-zinc-950 flex items-center justify-between border-b border-zinc-800">
              <div className="flex items-center gap-2 truncate pr-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-600 shrink-0" />
                <h3 className="text-sm sm:text-base font-bold text-white truncate">
                  {selectedMedia.title || selectedMedia.name}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                  {uBlockActive ? 'Protected by uBlock' : 'Unfiltered'}
                </span>
              </div>
              <button
                onClick={() => setSelectedMedia(null)}
                className="text-zinc-400 hover:text-white text-xl w-8 h-8 rounded-full hover:bg-zinc-800 flex items-center justify-center transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* TV Show Season & Episode Selectors */}
            {(selectedMedia.media_type === 'tv' || (!selectedMedia.title && selectedMedia.name)) && (
              <div className="p-3 bg-zinc-900 border-b border-zinc-800 flex flex-wrap gap-3 text-xs">
                <label className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-lg border border-zinc-800">
                  <span className="text-zinc-400 font-semibold">Season:</span>
                  <select
                    value={season}
                    onChange={e => setSeason(Number(e.target.value))}
                    className="bg-transparent text-white font-bold outline-none cursor-pointer"
                  >
                    {[1, 2, 3, 4, 5].map(s => (
                      <option key={s} value={s} className="bg-zinc-900 text-white">Season {s}</option>
                    ))}
                  </select>
                </label>

                <label className="flex items-center gap-2 bg-zinc-950 px-3 py-1.5 rounded-lg border border-zinc-800 flex-1 min-w-[200px]">
                  <span className="text-zinc-400 font-semibold">Episode:</span>
                  <select
                    value={episode}
                    onChange={e => setEpisode(Number(e.target.value))}
                    className="bg-transparent text-white font-bold outline-none cursor-pointer w-full"
                  >
                    {Array.from({ length: totalEpisodes }, (_, i) => i + 1).map(ep => (
                      <option key={ep} value={ep} className="bg-zinc-900 text-white">Episode {ep} - Streaming Release</option>
                    ))}
                  </select>
                </label>
              </div>
            )}

            {/* Video Player Frame */}
            <div className="aspect-video bg-black relative">
              <iframe
                title="Moon TV Player"
                src={getPlayerUrl()}
                className="w-full h-full border-0"
                allowFullScreen
                allow="autoplay; fullscreen; picture-in-picture"
              />
            </div>

            {/* Modal Footer / Server Switcher */}
            <div className="p-3 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between flex-wrap gap-2 text-xs">
              <span className="text-zinc-400 flex items-center gap-1.5">
                <Tv className="w-3.5 h-3.5 text-red-500" /> Streaming Server:
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentServer('vidsrc')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition ${
                    currentServer === 'vidsrc'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  Server 1 (VidSrc)
                </button>
                <button
                  onClick={() => setCurrentServer('2embed')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition ${
                    currentServer === '2embed'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                      : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  Server 2 (2Embed)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* uBlock Origin Dashboard / Popup Simulator Modal */}
      {showUBlockModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#1b1c20] border border-zinc-700 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl text-white">
            {/* uBlock Header */}
            <div className="bg-[#141518] px-4 py-3 flex items-center justify-between border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-red-800 flex items-center justify-center text-xs font-bold text-white">
                  u0
                </div>
                <span className="font-bold text-sm">uBlock Origin</span>
                <span className="text-[10px] text-zinc-400 font-mono">v1.60.0</span>
              </div>
              <button onClick={() => setShowUBlockModal(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* uBlock Body */}
            <div className="p-6 flex flex-col items-center gap-4 text-center">
              {/* Power Switch Button */}
              <button
                onClick={() => setUBlockActive(!uBlockActive)}
                className={`w-20 h-20 rounded-full flex items-center justify-center border-4 transition-all duration-300 shadow-xl ${
                  uBlockActive
                    ? 'bg-blue-600 border-blue-400/60 text-white shadow-blue-600/30 hover:scale-105'
                    : 'bg-zinc-800 border-zinc-700 text-zinc-500'
                }`}
                title="Click to toggle uBlock Origin on this site"
              >
                <Power className="w-10 h-10" />
              </button>

              <div>
                <span className="font-mono text-xs text-zinc-400">Current Scope:</span>
                <div className="font-bold text-sm text-white">127.0.0.1:8080 (Moon TV)</div>
              </div>

              {/* Counters */}
              <div className="w-full bg-[#141518] rounded-xl p-3 border border-zinc-800/80 flex justify-around text-xs">
                <div>
                  <div className="text-xl font-bold font-mono text-blue-400">{uBlockActive ? blockedStats.adsBlocked : 0}</div>
                  <div className="text-[10px] text-zinc-400">requests on this page</div>
                </div>
                <div className="w-px bg-zinc-800" />
                <div>
                  <div className="text-xl font-bold font-mono text-emerald-400">{uBlockActive ? '100%' : '0%'}</div>
                  <div className="text-[10px] text-zinc-400">clean streaming</div>
                </div>
              </div>

              {/* Filter List Status */}
              <div className="w-full text-left text-[11px] text-zinc-400 space-y-1 bg-zinc-900/60 p-3 rounded-lg border border-zinc-800">
                <div className="font-semibold text-zinc-300 mb-1">Active Filter Lists:</div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Check className="w-3 h-3" /> uBlock filters – Badware, Privacy, Quick fixes
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Check className="w-3 h-3" /> EasyList &amp; EasyPrivacy
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Check className="w-3 h-3" /> Peter Lowe’s Ad and tracking server list
                </div>
              </div>
            </div>

            <div className="bg-[#141518] px-4 py-2.5 border-t border-zinc-800 flex justify-end">
              <button
                onClick={() => setShowUBlockModal(false)}
                className="px-4 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-6 text-center text-xs text-zinc-500">
        <p className="mb-1">Moon TV Native Android Applet with Mozilla GeckoView &amp; uBlock Origin</p>
        <p className="text-zinc-600">Bundled signed XPI: <code>uBlock0@raymondhill.net</code> | TMDB API Integration</p>
      </footer>
    </div>
  );
}
